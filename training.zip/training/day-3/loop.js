function add(a, b) {
    return a + b;
}

let sum = add(3, 5); // Calling the function
console.log(sum); // Output: 8
