// // import React, { useRef, useEffect } from 'react'

// // const Ref = () => {
// //     let demo = useRef()
// //     let demo1 = useRef()

// //     useEffect(() => {
// //         if (demo.current) {
// //             console.log(demo);
// //             console.log(demo.current);
// //             demo.current.style.backgroundColor = "red";
// //         }
// //         if (demo1.current) {
// //             console.log(demo1);
// //             console.log(demo1.current);
// //             demo1.current.style.backgroundColor = "crimson";
// //         }
// //     }, []);

// //     return (
// //         <div>
// //             <h1 ref={demo}>hello world</h1>
// //             <h2 ref={demo1}>iam chitti</h2>
// //         </div>
// //     )
// // }

// // export default Ref

// import React from 'react'

// const Ref = () => {
//   let demo1 = React.useRef()
//   console.log(demo1);
//   let eventHandler = () => {
//     demo1.current.style.backgroundColor = "rosybrown";
//   }
//   return (
//     <div>
//       <h2 ref={demo1}>hello world</h2>
//       <button onClick={eventHandler}>Change Color</button>
//     </div>
//   )
// }

// export default Ref

import React from 'react'
const Ref = () => {
  let name = React.useRef()
  let password = React.useRef()

  let demo = (e) => {
    e.preventDefault()
    console.log({name:name.current.value});
    console.log({password:password.current.value});
  }
  return (
    <div>
      <form action="">
        <lable htmlFor="name">Name:</lable>
        <input type="text" name="name" id="name" ref={name} />
        <br />
        <lable htmlFor="password">Password:</lable>
        <input type="password" name="password" id="password"  ref={password}/>
        <br />
        <button onClick={demo}>Submit</button>
      </form>
    </div>
  )
}

export default Ref