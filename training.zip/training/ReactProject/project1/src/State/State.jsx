// // import React,{useState} from 'react'

// // const State = () => {
// //     let [count, setCount] = useState("Hello")
// //     console.log(count);
// //     console.log(setCount);

// //     let demo = () => {
// //       let [count, setCount] = useState(0)
// //       let decr = () => {
// //         setCount(count - 1)
// //       }
// //       let incr = () => {
// //         setCount(count + 1)
// //       }
// //       let reset = () => {
// //         setCount(0)
// //       }
// //     }
// //   return (
// //     <div>
// //         <button onClick={incr}>increment</button>
// //         <button onClick={reset}>reset</button>
// //         <button onClick={decr}>decrement</button>
// //     </div>
// //   )
// // }

// // export default State
// import React, {useState} from 'react'

// const State = () => {
//   let [name , setName] = useState()
//   let [password , setPassword] = useState()

//   let demo = (e) =>{
//     e.preventDefault()
//     console.log({name, password}); 

//     name === 'kranthi' && password === '143'? window.open("http://www.youtube.com/"):window.location.reload()
//   }

//   return (
//     <div>
//       <form action="">
//         <label htmlFor ="name">Name:</label>
//         <input type="text" name="name" id="name" value={name}
//         onChange={(e)=>{setName(e.target.value)}}/>

//         <br/>
//         <label htmlFor="password">Password:</label>
//         <input type="password" name="password" id="password" value={password}
//         onChange={(e)=>{setPassword(e.target.value)}}/> 
//         <br/>

//         <button onClick={demo}>submit</button>     
//         </form>
//     </div>
//   )
// }

// export default State

import React,{useState} from 'react'
import video1 from "./1.mp4"

const State = () => {
  let [state,setState]=useState(true)
  let demo = () =>{
    let demo1 = document.getElementById("demo")
    console.log(demo);
    setState(!state)
    state === true ? demo1.play() : demo1.pause()
  }
  return (
    <div>
      <video src={video1}  id='demo' onClick={demo}></video>
    </div>
  )
}

export default State

