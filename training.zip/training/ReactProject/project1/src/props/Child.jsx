// import React from 'react';
// class Child extends React.Component {
//   render() {
//     return(
//         <>
//             <h1>My name is {this.props.name}</h1>
//         </>
//     )
//   }
// }
// export default Child;

import React from 'react'
const Child = (props) => {
  // console.log(props.obj)
  // let {name,age,designation}=props.obj
  // console.log(name);
  // console.log(age);
  // console.log(designation);
  return (
    <div>
      {/* <h1>My name is {props.name}</h1> */}
      {/* <h1>My age is {props.age}</h1> */}
      {/* <h1>My array is {props.arr}</h1> */}
      {/* <h1>My name is {props.obj.name}</h1>
      <h1>My age is {age}</h1>
      <h1>My designation is {designation}</h1> */}
      <button onClick={()=>props.fun1()}>ok</button>
    </div>
  )
}

export default Child