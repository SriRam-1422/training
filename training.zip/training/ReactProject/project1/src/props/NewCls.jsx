import React, { Component } from "react";

class UserProfile extends Component {
  render() {
    return (
      <div className="user-profile">
        <h2>Name: {this.props.name}</h2>
        <p>Age: {this.props.age}</p>
        <p>Location: {this.props.location}</p>
        <p>Id:{this.props.id}</p>
        <p>University:{this.props.university}</p>
      </div>
    );
  }
}

export default UserProfile;
