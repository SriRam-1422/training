// import React from 'react';
// import Child from './Child';
// class Parent extends React.Component {
//     state = {
//         username: "bhaji rao",
//     }
//   render() {
//     return (
//         <Child name={this.state.username}/>
//     );
//   }
// }
// export default Parent;

import React from 'react';
import Child from './Child';
const Parent = () => {
  let obj1={
    name:"king",
    age:21,
    designation :"developer"

  }
  let fun=()=>{
    window.alert("Puku mui")
  }
  return (
    <div>
      {/* <Child name="Kinguu"/>
         <Child age={21}/> */}
         {/* <Child arr={[1,2,3,4,5]}/>
         <Child arr={["king","queen","prince","princess"]}/> */}

          {/* <Child obj={obj1}/> */}
          <Child fun1={fun}/>
         
      </div>
  )
}

export default Parent

