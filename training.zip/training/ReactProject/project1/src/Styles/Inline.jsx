import React from 'react'

const Inline = () => {
  return (
    <>
        <h1 style={{backgroundColor:"red" , textAlign:"center" , textAlign:"center"}}>Hello world</h1>
    </>
  )
}

export default Inline;