import React from 'react'
import '../styles/External.css'
const External = () => {
  return (
    <div>
        <h1 id='demo'>hello</h1>
    </div>
  )
}

export default External