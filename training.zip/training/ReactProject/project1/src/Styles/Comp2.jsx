import React from 'react'

const Comp2 = () => {
  return (
    <>
        <section id="main">
            <h1>₹59.00 for 2 months of Premium Student</h1>
            <h2>Only ₹59.00/month after. Cancel anytime.</h2>
            <button>Get Premium</button>
            <p>Offer available only to students at an accredited higher education institution. Offer not available to users who already tried Premium.<br></br> Spotify Student Discount Offer <p1>Terms and conditions </p1>apply.</p>
            <h3>Soundtrack your study</h3>
        </section>
    </>
  )
}

export default Comp2