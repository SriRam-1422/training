import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
// import './index.css'
// import App from './App.jsx'
import Cbc from './component/Cbc.jsx'
import Fbc from './component/Fbc.jsx'
import Demo from './component/Demo.jsx'
import Parent from './props/Parent.jsx'
import Child from './props/Child.jsx'
import State from './State/State.jsx'
import Inline from './Styles/Inline.jsx'
import Comp1 from './Styles/Comp1.jsx'
// import "../src/Styles/globally.css"
import Comp2 from './Styles/Comp2.jsx'
import External from './Styles/External.jsx'
import Ref from './useRef/Ref.jsx'
import List from './list-keys/List.jsx'
createRoot(document.getElementById('root')).render(
  <StrictMode>
    {/* <Parent /> */}
    {/* <Inline /> */}
    {/* <Comp1/>
    <Comp2/> */}
    {/* <External/> */}
    {/* <Ref/> */}
    <List/>
  </StrictMode>,
)
