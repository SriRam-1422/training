import React from 'react'
class Cbc extends React.Component {
  render() {
    return <h1>Class Based Component</h1>
  }
}
export default Cbc;