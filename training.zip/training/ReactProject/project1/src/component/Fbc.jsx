import React from "react";
function Fbc() {
  return <h1>Functional Based Component</h1>;
}
export default Fbc;