// import React from 'react'

// const Demo = () => {
//   return (
//     <div>
//         {
//             React.createElement('h1', null, 'Hello World')
//         }
//         {
//             React.createElement("div", {id:"demo"}, React.createElement("span", "null", "iam span tag inside div"))
//         }
//     </div>
//   )
// }

// export default Demo;


import React from 'react'

const Demo = () => {
  return (
    <>
    <h1>Hello World</h1>
    <h2>Hi</h2>
    <h2>{5+5}</h2>
    </>
    )
}

export default Demo