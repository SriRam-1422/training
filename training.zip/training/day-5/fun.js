let b = function (a) {
    console.log(a);
    console.log(arguments[1]);
    console.log(arguments[2]);
}
b(1, 2, 3);