console.log('start');
let a = 1;
console.log(a);
console.log('end');